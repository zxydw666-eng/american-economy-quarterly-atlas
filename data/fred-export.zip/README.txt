----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-11-14 7:57 am CST
----------------------------------------------------------------

--------  --------------------------------------------------------------------  ------------------------
GDPC1     Real Gross Domestic Product, Billions of Chained 2017 Dollars,        Data Updated: 2026-10-29
          Quarterly, Seasonally Adjusted Annual Rate
UNRATE    Unemployment Rate, Percent, Monthly, Seasonally Adjusted              Data Updated: 2026-11-06
CPIAUCSL  Consumer Price Index for All Urban Consumers: All Items in U.S. City  Data Updated: 2026-11-10
          Average, Index 1982-1984=100, Monthly, Seasonally Adjusted
FEDFUNDS  Federal Funds Effective Rate, Percent, Monthly, Not Seasonally        Data Updated: 2026-11-02
          Adjusted
--------  --------------------------------------------------------------------  ------------------------

